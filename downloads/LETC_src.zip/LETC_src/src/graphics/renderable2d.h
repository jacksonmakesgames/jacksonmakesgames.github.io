#pragma once

#include "buffers/buffer.h"
#include "buffers/indexbuffer.h"
#include "buffers/vertexarray.h"

#include "renderer2d.h"

#include "../math/math.h"
#include "shader.h"


namespace letc {namespace graphics {
	struct VertexData
	{
		math::Vector3 vertex;
		//math::Vector4 color;
		unsigned int color;

	};

	class Renderable2D{
	protected:
		math::Vector2 m_size;
		math::Vector3 m_position;
		math::Vector4 m_color;

	protected:
		Renderable2D() {}


	public:
		Renderable2D(math::Vector3 position, math::Vector2 size, math::Vector4 color)
		: m_position(position), m_size(size), m_color(color){
		
		}

		virtual ~Renderable2D() {
		}

		virtual void submit(Renderer2D* renderer)const {
			renderer->submit(this);
		}


		inline const math::Vector2& getSize()const{ return m_size; };
		inline const math::Vector3& getPosition()const{ return m_position; };
		inline const math::Vector4& getColor()const{ return m_color; };

	};
}}