#pragma once
#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

namespace letc {namespace graphics {
#define MAX_KEYS 1024
#define MAX_BUTTONS 32

	class Window {
	public:
	private:
		friend struct GLFWwindow;
		const char* m_Title;
		int m_Width, m_Height;
		GLFWwindow *m_Window;
		bool m_Closed;

		bool m_Keys[MAX_KEYS];
		bool m_Buttons[MAX_BUTTONS];
		double mx, my;

	public:
		Window(const char *title, int width, int height);
		~Window();
		bool closed() const;
		void update();
		void clear() const;

		inline int getWidth() const { return Window::m_Width; };
		inline int getHeight() const { return Window::m_Height; };

		bool keyPressed(unsigned int keycode) const;
		bool mouseButtonPressed(unsigned int button) const;
		void getMousePos(double& x, double& y) const;

		void updateWindowSize(int width, int height);

	private:
		friend static void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods);
		friend static void mouse_button_callback(GLFWwindow* window, int button, int action, int mods);
		friend void cursor_position_callback(GLFWwindow* window, double xpos, double ypos);
		bool init();

	};



}}