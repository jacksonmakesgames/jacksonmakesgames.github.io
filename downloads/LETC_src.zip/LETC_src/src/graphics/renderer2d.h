#pragma once
#include <vector>
#include <GL/glew.h>
#include "../math/math.h"

namespace letc {namespace graphics {
	class Renderable2D;

	class Renderer2D{
	protected:
		std::vector<math::Matrix4> m_TransformationStack;
		const math::Matrix4* m_tranformationStackBack;

		Renderer2D() {
			m_TransformationStack.push_back(math::Matrix4::identity());
			m_tranformationStackBack = &m_TransformationStack.back();
		}
	public:
		void push(const math::Matrix4& mat, bool override = false) {
			if (override) {
				m_TransformationStack.push_back(mat);
			}
			else {
				m_TransformationStack.push_back(m_TransformationStack.back() * mat);
			}
			m_tranformationStackBack = &m_TransformationStack.back();

		}

		void pop() {
			if (m_TransformationStack.size() > 1) {
				m_TransformationStack.pop_back();
			}
			else {
				//TODO: log error
				std::cout << "ERROR: TRIED TO POP TOO MANY MAT4s" << std::endl;
				return;
			}
			m_tranformationStackBack = &m_TransformationStack.back();

		}

		virtual void begin() {}
		virtual void submit(const Renderable2D* renderable) = 0;
		virtual void end() {}
		virtual void flush() = 0;
	};

}}