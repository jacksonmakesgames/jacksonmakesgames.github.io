#include "batchrenderer2d.h"

namespace letc {namespace graphics {
	
	BatchRenderer2D::BatchRenderer2D() {
		init();
	}

	BatchRenderer2D::~BatchRenderer2D() {
		delete m_indexBuffer;
		glDeleteBuffers(1, &m_vertexBuffer);
	}

	void BatchRenderer2D::init(){
		glGenVertexArrays(1, &m_vertexArray);
		glGenBuffers(1, &m_vertexBuffer);

		glBindVertexArray(m_vertexArray);

		glBindBuffer(GL_ARRAY_BUFFER, m_vertexBuffer);

		glBufferData(GL_ARRAY_BUFFER, RENDERER_BUFFER_SIZE, NULL, GL_DYNAMIC_DRAW);
		glEnableVertexAttribArray(SHADER_VERTEX_INDEX);
		glEnableVertexAttribArray(SHADER_COLOR_INDEX);
		glVertexAttribPointer(SHADER_VERTEX_INDEX, 3, GL_FLOAT, GL_FALSE, RENDERER_VERTEX_SIZE, (const GLvoid*) 0);
		glVertexAttribPointer(SHADER_COLOR_INDEX, 4, GL_UNSIGNED_BYTE, GL_TRUE, RENDERER_VERTEX_SIZE, (const GLvoid*)(offsetof(VertexData, VertexData::color)));
		
		glBindBuffer(GL_ARRAY_BUFFER, NULL);

		int indexOffset = 0;
		GLushort indices[RENDERER_INDICES_SIZE];

		for (int i = 0; i < RENDERER_INDICES_SIZE; i += 6) {
			indices[i+0] = indexOffset + 0;
			indices[i+1] = indexOffset + 1;
			indices[i+2] = indexOffset + 2;
			
			indices[i+3] = indexOffset + 2;
			indices[i+4] = indexOffset + 3;
			indices[i+5] = indexOffset + 0;

			indexOffset += 4;

		}
		m_indexBuffer = new IndexBuffer(indices, RENDERER_INDICES_SIZE);

		glBindVertexArray(NULL);
	}

	void BatchRenderer2D::begin(){
		glBindBuffer(GL_ARRAY_BUFFER, m_vertexBuffer);
		m_buffer = (VertexData*) glMapBuffer(GL_ARRAY_BUFFER, GL_WRITE_ONLY);
	}

	void BatchRenderer2D::submit(const Renderable2D* renderable){
		const math::Vector3& pos = renderable->getPosition();
		const math::Vector2& size = renderable->getSize();
		const math::Vector4& color = renderable->getColor();

		int	r = color.x * 255.0f;
		int	g = color.y * 255.0f;
		int	b = color.z * 255.0f;
		int	a = color.w * 255.0f;

		unsigned int c = a << 24 | b << 16 | g << 8 | r;

		m_buffer->vertex = *m_tranformationStackBack * pos;
		m_buffer->color = c;
		m_buffer++;

		m_buffer->vertex = *m_tranformationStackBack * math::Vector3(pos.x, pos.y+size.y, pos.z);
		m_buffer->color = c;
		m_buffer++;

		m_buffer->vertex = *m_tranformationStackBack * math::Vector3(pos.x + size.x, pos.y + size.y, pos.z);
		m_buffer->color = c;
		m_buffer++;

		m_buffer->vertex = *m_tranformationStackBack * math::Vector3(pos.x + size.x, pos.y, pos.z);
		m_buffer->color = c;
		m_buffer++;

		m_indexCount += 6;
	}

	void BatchRenderer2D::end(){
		glUnmapBuffer(GL_ARRAY_BUFFER);
		glBindBuffer(GL_ARRAY_BUFFER, NULL);
	}

	void BatchRenderer2D::flush(){
		glBindVertexArray(m_vertexArray);
		GLenum error = glGetError();
		if (error != GL_NO_ERROR) {
			std::cout << "OpenGL Error In Batch: " << error << std::endl;
		}
		
		m_indexBuffer->bind();

		glDrawElements(GL_TRIANGLES, m_indexCount, GL_UNSIGNED_SHORT, NULL);

		m_indexBuffer->unbind();
		glBindVertexArray(NULL);

		m_indexCount = 0;

	}

}}