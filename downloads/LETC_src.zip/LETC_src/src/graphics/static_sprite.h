#pragma once
#include "renderable2d.h"

namespace letc {namespace graphics {
	class StaticSprite : public Renderable2D {
		VertexArray* m_vertexArray;
		IndexBuffer* m_indexBuffer;
		Shader& m_shader;

	public:
		StaticSprite(float x, float y, float width, float height, const math::Vector4& color, Shader& shader);
		~StaticSprite();

		
		inline const VertexArray* getVertexArray()const{ return m_vertexArray; };
		inline const IndexBuffer* getIndexBuffer()const{ return m_indexBuffer; };
		inline Shader& getShader()const{ return m_shader; };
	};
}}